# 摄影管理

照片按三级文件夹管理，支持导入、缩略图预览、笔记。

## 下载使用

👉 [下载最新版本](../../releases) — 解压后双击 `摄影管理.exe` 即可，无需安装 Python。

## 功能

- 三级文件夹管理（文件夹 → 文件夹 → 文件夹）
- 照片导入，支持 JPEG / PNG / WebP / HEIC / GIF / BMP
- 自动生成压缩预览图
- 每个文件夹/照片独立笔记
- 导入时可选择复制照片到程序目录，支持原尺寸/1080P/720P/540P
- 浅色极简 UI

## 开发

```bash
pip install -r requirements.txt
python main.py
```
