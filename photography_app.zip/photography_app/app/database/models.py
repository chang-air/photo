from sqlalchemy import create_engine, Column, Integer, String, Text, Float, DateTime, ForeignKey, JSON
from sqlalchemy.orm import declarative_base, relationship
from datetime import datetime, timezone

Base = declarative_base()


class Lens(Base):
    __tablename__ = 'lenses'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))

    styles = relationship('Style', back_populates='lens', cascade='all, delete-orphan',
                          order_by='Style.sort_order')


class Style(Base):
    __tablename__ = 'styles'

    id = Column(Integer, primary_key=True, autoincrement=True)
    lens_id = Column(Integer, ForeignKey('lenses.id', ondelete='CASCADE'), nullable=False)
    name = Column(String(100), nullable=False)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))

    lens = relationship('Lens', back_populates='styles')
    folders = relationship('Folder', back_populates='style', cascade='all, delete-orphan',
                           order_by='Folder.sort_order')


class Folder(Base):
    __tablename__ = 'folders'

    id = Column(Integer, primary_key=True, autoincrement=True)
    style_id = Column(Integer, ForeignKey('styles.id', ondelete='CASCADE'), nullable=False)
    name = Column(String(100), nullable=False)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))

    style = relationship('Style', back_populates='folders')
    photos = relationship('Photo', back_populates='folder', cascade='all, delete-orphan')


class Photo(Base):
    __tablename__ = 'photos'

    id = Column(Integer, primary_key=True, autoincrement=True)
    folder_id = Column(Integer, ForeignKey('folders.id', ondelete='CASCADE'), nullable=False)
    original_path = Column(String(500), nullable=False)
    preview_path = Column(String(500), nullable=False)
    width = Column(Integer)
    height = Column(Integer)
    file_size = Column(Integer)
    format = Column(String(10))
    exif_data = Column(JSON)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))

    folder = relationship('Folder', back_populates='photos')
    notes = relationship('Note', back_populates='photo', cascade='all, delete-orphan',
                         primaryjoin="and_(Photo.id == foreign(Note.target_id), Note.target_type == 'photo')")


class Note(Base):
    __tablename__ = 'notes'

    id = Column(Integer, primary_key=True, autoincrement=True)
    target_type = Column(String(10), nullable=False)  # 'photo' or 'folder'
    target_id = Column(Integer, nullable=False)
    content = Column(Text, default='')
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))

    photo = relationship('Photo', back_populates='notes',
                         primaryjoin="and_(Note.target_type == 'photo', foreign(Note.target_id) == Photo.id)")
