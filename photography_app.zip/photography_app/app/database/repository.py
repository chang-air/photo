from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker
from .models import Base

DB_PATH = None
engine = None
Session = None


def init_db(db_path):
    global DB_PATH, engine, Session
    DB_PATH = db_path
    engine = create_engine(f'sqlite:///{db_path}')

    @event.listens_for(engine, 'connect')
    def set_sqlite_pragma(dbapi_connection, connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute('PRAGMA journal_mode=WAL')
        cursor.execute('PRAGMA foreign_keys=ON')
        cursor.close()

    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)


def get_session():
    return Session()
