from app.database.repository import get_session
from app.database.models import Folder


def create_folder(style_id: int, name: str) -> Folder:
    session = get_session()
    count = session.query(Folder).filter_by(style_id=style_id).count()
    folder = Folder(style_id=style_id, name=name, sort_order=count)
    session.add(folder)
    session.commit()
    session.refresh(folder)
    session.close()
    return folder


def get_folders_by_style(style_id: int) -> list[Folder]:
    session = get_session()
    folders = session.query(Folder).filter_by(style_id=style_id).order_by(Folder.sort_order).all()
    session.close()
    return folders


def rename_folder(folder_id: int, new_name: str):
    session = get_session()
    session.query(Folder).filter_by(id=folder_id).update({'name': new_name})
    session.commit()
    session.close()


def delete_folder(folder_id: int):
    session = get_session()
    session.query(Folder).filter_by(id=folder_id).delete()
    session.commit()
    session.close()


def reorder_folders(ordered_ids: list[int]):
    session = get_session()
    for i, fid in enumerate(ordered_ids):
        session.query(Folder).filter_by(id=fid).update({'sort_order': i})
    session.commit()
    session.close()
