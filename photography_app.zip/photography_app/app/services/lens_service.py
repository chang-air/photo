from app.database.repository import get_session
from app.database.models import Lens


def create_lens(name: str) -> Lens:
    session = get_session()
    count = session.query(Lens).count()
    lens = Lens(name=name, sort_order=count)
    session.add(lens)
    session.commit()
    session.refresh(lens)
    session.close()
    return lens


def get_all_lenses() -> list[Lens]:
    session = get_session()
    lenses = session.query(Lens).order_by(Lens.sort_order).all()
    session.close()
    return lenses


def rename_lens(lens_id: int, new_name: str):
    session = get_session()
    session.query(Lens).filter_by(id=lens_id).update({'name': new_name})
    session.commit()
    session.close()


def delete_lens(lens_id: int):
    session = get_session()
    session.query(Lens).filter_by(id=lens_id).delete()
    session.commit()
    session.close()


def reorder_lenses(ordered_ids: list[int]):
    session = get_session()
    for i, lid in enumerate(ordered_ids):
        session.query(Lens).filter_by(id=lid).update({'sort_order': i})
    session.commit()
    session.close()
