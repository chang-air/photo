from app.database.repository import get_session
from app.database.models import Note


def create_note(target_type: str, target_id: int, content: str = '') -> Note:
    session = get_session()
    note = Note(target_type=target_type, target_id=target_id, content=content)
    session.add(note)
    session.commit()
    session.refresh(note)
    session.close()
    return note


def get_notes(target_type: str, target_id: int) -> list[Note]:
    session = get_session()
    notes = session.query(Note).filter_by(
        target_type=target_type, target_id=target_id
    ).all()
    session.close()
    return notes


def update_note(note_id: int, content: str):
    session = get_session()
    session.query(Note).filter_by(id=note_id).update({'content': content})
    session.commit()
    session.close()


def delete_note(note_id: int):
    session = get_session()
    session.query(Note).filter_by(id=note_id).delete()
    session.commit()
    session.close()


def search_notes(query: str) -> list[Note]:
    session = get_session()
    notes = session.query(Note).filter(Note.content.contains(query)).all()
    session.close()
    return notes
