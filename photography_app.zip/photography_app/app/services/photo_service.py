import os
import uuid
import shutil
from datetime import datetime, timezone
from PIL import Image
from app.database.repository import get_session
from app.database.models import Photo
from app.thumbnail.generator import generate_preview, get_image_metadata


def import_photos(folder_id: int, file_paths: list[str], thumbnails_dir: str) -> list[Photo]:
    session = get_session()
    photos = []
    for src in file_paths:
        ext = os.path.splitext(src)[1]
        preview_id = uuid.uuid4().hex
        preview_path = os.path.join(thumbnails_dir, f'{preview_id}.jpg')

        metadata = get_image_metadata(src)
        if metadata is None:
            continue

        try:
            w, h, size = generate_preview(src, preview_path)
        except Exception:
            continue

        photo = Photo(
            folder_id=folder_id,
            original_path=os.path.abspath(src),
            preview_path=os.path.abspath(preview_path),
            width=w,
            height=h,
            file_size=size,
            format=metadata['format'],
            exif_data=metadata.get('exif'),
        )
        session.add(photo)
        photos.append(photo)

    session.commit()
    for p in photos:
        session.refresh(p)
    session.close()
    return photos


def get_photos_by_folder(folder_id: int) -> list[Photo]:
    session = get_session()
    photos = session.query(Photo).filter_by(folder_id=folder_id).all()
    session.close()
    return photos


def delete_photo(photo_id: int):
    session = get_session()
    photo = session.query(Photo).filter_by(id=photo_id).first()
    if photo:
        if os.path.exists(photo.preview_path):
            os.remove(photo.preview_path)
        session.delete(photo)
        session.commit()
    session.close()


RESIZE_MAX = {
    '1080p': (1920, 1080),
    '720p': (1280, 720),
    '540p': (960, 540),
}


def copy_photo(src: str, dest_dir: str, resolution: str) -> str:
    """Copy a photo to dest_dir, optionally resizing. Returns the new path."""
    os.makedirs(dest_dir, exist_ok=True)
    base = os.path.basename(src)
    name, ext = os.path.splitext(base)
    ext = ext.lower()
    if ext == '.jpeg':
        ext = '.jpg'

    img = Image.open(src)
    max_size = RESIZE_MAX.get(resolution)

    if max_size and (img.width > max_size[0] or img.height > max_size[1]):
        ratio = min(max_size[0] / img.width, max_size[1] / img.height)
        new_size = (int(img.width * ratio), int(img.height * ratio))
        img = img.resize(new_size, Image.LANCZOS)

    if img.mode in ('RGBA', 'P'):
        img = img.convert('RGB')

    dest = os.path.join(dest_dir, f'{name}{ext}')
    # Avoid overwriting
    counter = 1
    while os.path.exists(dest):
        dest = os.path.join(dest_dir, f'{name}_{counter}{ext}')
        counter += 1

    save_fmt = 'JPEG' if ext in ('.jpg', '.jpeg') else ext.upper().lstrip('.')
    img.save(dest, format=save_fmt)
    img.close()
    return dest


def get_photo_count(folder_id: int) -> int:
    session = get_session()
    count = session.query(Photo).filter_by(folder_id=folder_id).count()
    session.close()
    return count


def get_photos_by_target(target_type: str, target_id: int) -> list[Photo]:
    """Get all photos under a lens, style, or folder (recursively)."""
    from app.database.models import Lens, Style, Folder
    session = get_session()
    if target_type == 'folder':
        photos = session.query(Photo).filter_by(folder_id=target_id).all()
    elif target_type == 'style':
        folders = session.query(Folder).filter_by(style_id=target_id).all()
        folder_ids = [f.id for f in folders]
        photos = session.query(Photo).filter(Photo.folder_id.in_(folder_ids)).all() if folder_ids else []
    elif target_type == 'lens':
        styles = session.query(Style).filter_by(lens_id=target_id).all()
        style_ids = [s.id for s in styles]
        folders = session.query(Folder).filter(Folder.style_id.in_(style_ids)).all() if style_ids else []
        folder_ids = [f.id for f in folders]
        photos = session.query(Photo).filter(Photo.folder_id.in_(folder_ids)).all() if folder_ids else []
    else:
        photos = []
    session.close()
    return photos


def ensure_target_folder(target_type: str, target_id: int) -> int:
    """For lens/style targets, ensure a default sub-folder chain exists.
    Returns the folder_id to import into."""
    from app.database.models import Style, Folder

    if target_type == 'folder':
        return target_id

    session = get_session()
    try:
        if target_type == 'style':
            folder = session.query(Folder).filter_by(style_id=target_id).first()
            if not folder:
                count = session.query(Folder).filter_by(style_id=target_id).count()
                folder = Folder(style_id=target_id, name='默认', sort_order=count)
                session.add(folder)
                session.commit()
            fid = folder.id
        elif target_type == 'lens':
            style = session.query(Style).filter_by(lens_id=target_id).first()
            if not style:
                count = session.query(Style).filter_by(lens_id=target_id).count()
                style = Style(lens_id=target_id, name='默认', sort_order=count)
                session.add(style)
                session.commit()
            folder = session.query(Folder).filter_by(style_id=style.id).first()
            if not folder:
                folder_count = session.query(Folder).filter_by(style_id=style.id).count()
                folder = Folder(style_id=style.id, name='默认', sort_order=folder_count)
                session.add(folder)
                session.commit()
            fid = folder.id
        else:
            fid = target_id
    finally:
        session.close()
    return fid
