from app.database.repository import get_session
from app.database.models import Style


def create_style(lens_id: int, name: str) -> Style:
    session = get_session()
    count = session.query(Style).filter_by(lens_id=lens_id).count()
    style = Style(lens_id=lens_id, name=name, sort_order=count)
    session.add(style)
    session.commit()
    session.refresh(style)
    session.close()
    return style


def get_styles_by_lens(lens_id: int) -> list[Style]:
    session = get_session()
    styles = session.query(Style).filter_by(lens_id=lens_id).order_by(Style.sort_order).all()
    session.close()
    return styles


def rename_style(style_id: int, new_name: str):
    session = get_session()
    session.query(Style).filter_by(id=style_id).update({'name': new_name})
    session.commit()
    session.close()


def delete_style(style_id: int):
    session = get_session()
    session.query(Style).filter_by(id=style_id).delete()
    session.commit()
    session.close()


def reorder_styles(ordered_ids: list[int]):
    session = get_session()
    for i, sid in enumerate(ordered_ids):
        session.query(Style).filter_by(id=sid).update({'sort_order': i})
    session.commit()
    session.close()
