"""Thumbnail generator using Pillow + pillow-heif.

Supported formats: JPEG, PNG, WebP, HEIC, GIF, BMP.
Output: JPEG, quality 85%, long edge ≤ 1920px.
"""

import os
import io
from PIL import Image

PREVIEW_MAX_PX = 1920
PREVIEW_QUALITY = 85
PREVIEW_FORMAT = 'JPEG'


def generate_preview(original_path: str, output_path: str) -> tuple[int, int, int]:
    """Generate a compressed preview JPEG. Returns (width, height, file_size)."""
    img = _open_image(original_path)
    if img is None:
        raise ValueError(f'Cannot open image: {original_path}')

    w, h = img.size
    ratio = PREVIEW_MAX_PX / max(w, h)
    if ratio < 1.0:
        new_size = (int(w * ratio), int(h * ratio))
        img = img.resize(new_size, Image.LANCZOS)

    if img.mode in ('RGBA', 'P'):
        img = img.convert('RGB')
    elif img.mode == 'CMYK':
        img = img.convert('RGB')

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    img.save(output_path, format=PREVIEW_FORMAT, quality=PREVIEW_QUALITY)

    file_size = os.path.getsize(output_path)
    return (img.width, img.height, file_size)


def _open_image(path: str) -> Image.Image | None:
    """Open an image, handling HEIC via pillow-heif if needed."""
    ext = os.path.splitext(path)[1].lower()

    if ext in ('.heic', '.heif'):
        try:
            from pillow_heif import register_heif_opener
            register_heif_opener()
        except ImportError:
            pass

    try:
        img = Image.open(path)
        return img
    except Exception:
        return None


def get_image_metadata(path: str) -> dict | None:
    """Extract basic metadata from an image file."""
    img = _open_image(path)
    if img is None:
        return None
    exif = {}
    try:
        raw = img.getexif()
        if raw:
            for k, v in raw.items():
                exif[str(k)] = str(v)
    except Exception:
        pass
    return {
        'width': img.width,
        'height': img.height,
        'format': img.format or os.path.splitext(path)[1].upper().lstrip('.'),
        'exif': exif,
    }
