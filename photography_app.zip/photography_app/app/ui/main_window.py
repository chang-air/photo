import os
from PySide6.QtWidgets import (
    QMainWindow, QSplitter, QTreeView, QListView, QTextEdit,
    QVBoxLayout, QHBoxLayout, QWidget, QLabel, QPushButton,
    QToolBar, QLineEdit, QMenu, QAbstractItemView, QInputDialog,
    QMessageBox, QFileDialog, QTextBrowser,
)
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QAction, QStandardItemModel, QStandardItem, QIcon, QPixmap

from app.database.repository import get_session
from app.database.models import Lens, Style, Folder, Photo, Note
from app.services.lens_service import create_lens, rename_lens, delete_lens, get_all_lenses
from app.services.style_service import create_style, rename_style, delete_style
from app.services.folder_service import create_folder, rename_folder, delete_folder
from app.services.photo_service import import_photos, get_photos_by_target, ensure_target_folder, delete_photo, copy_photo
from app.services.note_service import get_notes, create_note, update_note
from app.utils.settings import load_settings, save_settings
from app.ui.widgets.settings_dialog import SettingsDialog


class MainWindow(QMainWindow):
    def __init__(self, data_dir: str):
        super().__init__()
        self.data_dir = data_dir
        self.thumbnails_dir = os.path.join(data_dir, 'thumbnails')
        self.photos_dir = os.path.join(data_dir, 'photos')
        self.settings = load_settings(data_dir)
        self._current_note_target = None  # (type, id) or None

        self.setWindowTitle('摄影管理')
        self.resize(1280, 800)
        self.setMinimumSize(960, 600)

        self._setup_toolbar()
        self._setup_central_widget()
        self._setup_tree_model()
        self._connect_signals()
        self._refresh_tree()

    # ── toolbar ──────────────────────────────────────────────

    def _setup_toolbar(self):
        toolbar = QToolBar()
        toolbar.setMovable(False)
        toolbar.setIconSize(QSize(20, 20))
        self.addToolBar(toolbar)

        title = QLabel('摄影管理')
        title.setObjectName('title')
        toolbar.addWidget(title)

        spacer = QWidget()
        spacer.setFixedWidth(24)
        toolbar.addWidget(spacer)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText('搜索笔记...')
        self.search_input.setFixedWidth(200)
        self.search_input.textChanged.connect(self._on_search_notes)
        toolbar.addWidget(self.search_input)

        spacer2 = QWidget()
        spacer2.setFixedWidth(8)
        toolbar.addWidget(spacer2)

        settings_btn = QPushButton('⚙ 设置')
        settings_btn.clicked.connect(self._on_open_settings)
        toolbar.addWidget(settings_btn)

    # ── central layout ───────────────────────────────────────

    def _setup_central_widget(self):
        splitter = QSplitter(Qt.Horizontal)
        splitter.setHandleWidth(1)

        # -- Left: tree -------------------------------------------------
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(0)

        left_header = QWidget()
        left_header_layout = QHBoxLayout(left_header)
        left_header_layout.setContentsMargins(8, 8, 8, 4)
        header_label = QLabel('库')
        header_label.setObjectName('subtitle')
        left_header_layout.addWidget(header_label)
        left_header_layout.addStretch()
        add_btn = QPushButton('+')
        add_btn.setFixedSize(28, 28)
        add_btn.clicked.connect(self._on_add_lens)
        left_header_layout.addWidget(add_btn)
        left_layout.addWidget(left_header)

        self.tree = QTreeView()
        self.tree.setHeaderHidden(True)
        self.tree.setEditTriggers(QAbstractItemView.DoubleClicked)
        self.tree.setDragDropMode(QAbstractItemView.InternalMove)
        self.tree.setDefaultDropAction(Qt.MoveAction)
        left_layout.addWidget(self.tree)

        splitter.addWidget(left_widget)

        # -- Center: thumbnails -----------------------------------------
        center_widget = QWidget()
        center_layout = QVBoxLayout(center_widget)
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(0)

        center_header = QWidget()
        center_header_layout = QHBoxLayout(center_header)
        center_header_layout.setContentsMargins(8, 8, 8, 4)
        self.center_title = QLabel('全部照片')
        self.center_title.setObjectName('title')
        center_header_layout.addWidget(self.center_title)
        center_header_layout.addStretch()
        self.import_btn = QPushButton('导入')
        self.import_btn.setObjectName('primaryBtn')
        self.import_btn.clicked.connect(self._on_import_photos)
        self.import_btn.setEnabled(False)
        center_header_layout.addWidget(self.import_btn)
        center_layout.addWidget(center_header)

        self.thumbnail_grid = QListView()
        self.thumbnail_grid.setViewMode(QListView.IconMode)
        self.thumbnail_grid.setIconSize(QSize(200, 150))
        self.thumbnail_grid.setResizeMode(QListView.Adjust)
        self.thumbnail_grid.setSpacing(8)
        self.thumbnail_grid.setSelectionMode(QAbstractItemView.ExtendedSelection)
        center_layout.addWidget(self.thumbnail_grid)

        self.photo_model = QStandardItemModel()
        self.thumbnail_grid.setModel(self.photo_model)
        self._selected_target = None  # (type, id) or None

        splitter.addWidget(center_widget)

        # -- Right: notes -----------------------------------------------
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)

        right_header = QWidget()
        right_header_layout = QHBoxLayout(right_header)
        right_header_layout.setContentsMargins(8, 8, 8, 4)
        notes_label = QLabel('笔记')
        notes_label.setObjectName('subtitle')
        right_header_layout.addWidget(notes_label)
        right_header_layout.addStretch()
        right_layout.addWidget(right_header)

        self.note_editor = QTextEdit()
        self.note_editor.setPlaceholderText('选择照片或文件夹以添加笔记...')
        right_layout.addWidget(self.note_editor)

        exif_label = QLabel('信息')
        exif_label.setObjectName('subtitle')
        right_layout.addWidget(exif_label)

        self.exif_browser = QTextBrowser()
        self.exif_browser.setMaximumHeight(200)
        self.exif_browser.setPlaceholderText('选择照片以查看EXIF信息...')
        right_layout.addWidget(self.exif_browser)

        splitter.addWidget(right_widget)
        splitter.setSizes([280, 680, 320])
        self.setCentralWidget(splitter)

    # ── tree model ───────────────────────────────────────────

    def _setup_tree_model(self):
        self.tree_model = QStandardItemModel()
        self.tree.setModel(self.tree_model)

    def _connect_signals(self):
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._on_tree_context_menu)
        self.tree.selectionModel().selectionChanged.connect(self._on_tree_selection_changed)
        self.tree_model.rowsMoved.connect(self._on_tree_rows_moved)

        self.thumbnail_grid.doubleClicked.connect(self._on_photo_double_click)
        self.thumbnail_grid.selectionModel().selectionChanged.connect(self._on_photo_selection_changed)
        self.thumbnail_grid.setContextMenuPolicy(Qt.CustomContextMenu)
        self.thumbnail_grid.customContextMenuRequested.connect(self._on_photo_context_menu)

        self.note_editor.textChanged.connect(self._on_note_text_changed)

    def _refresh_tree(self, expand_type=None, expand_id=None):
        session = get_session()
        self.tree_model.clear()
        self.tree_model.setHorizontalHeaderLabels([''])
        lenses = session.query(Lens).order_by(Lens.sort_order).all()
        for lens in lenses:
            lens_item = QStandardItem(lens.name)
            lens_item.setData({'type': 'lens', 'id': lens.id}, Qt.UserRole)
            lens_item.setEditable(True)
            for style in lens.styles:
                style_item = QStandardItem(style.name)
                style_item.setData({'type': 'style', 'id': style.id}, Qt.UserRole)
                style_item.setEditable(True)
                for folder in style.folders:
                    folder_item = QStandardItem(folder.name)
                    folder_item.setData({'type': 'folder', 'id': folder.id}, Qt.UserRole)
                    folder_item.setEditable(True)
                    style_item.appendRow(folder_item)
                lens_item.appendRow(style_item)
            self.tree_model.appendRow(lens_item)
        session.close()

        if expand_type and expand_id:
            idx = self._find_item_index(expand_type, expand_id)
            if idx.isValid():
                self.tree.expand(idx)

    def _find_item_index(self, item_type, item_id):
        """Find QModelIndex for a tree item by type and id (after model rebuild)."""
        root = self.tree_model.invisibleRootItem()

        def _search(parent):
            for i in range(parent.rowCount()):
                child = parent.child(i)
                data = child.data(Qt.UserRole)
                if data and data.get('type') == item_type and data.get('id') == item_id:
                    return self.tree_model.indexFromItem(child)
                result = _search(child)
                if result and result.isValid():
                    return result
            return None

        result = _search(root)
        return result if result and result.isValid() else self.tree_model.index(-1, -1)

    def _get_selected_item_data(self):
        """Return the data dict of the currently selected tree item, or None."""
        indexes = self.tree.selectedIndexes()
        if not indexes:
            return None
        item = self.tree_model.itemFromIndex(indexes[0])
        return item.data(Qt.UserRole) if item else None

    # ── tree context menu ────────────────────────────────────

    def _on_tree_context_menu(self, pos):
        menu = QMenu()
        index = self.tree.indexAt(pos)

        if index.isValid():
            item = self.tree_model.itemFromIndex(index)
            data = item.data(Qt.UserRole)
            if data is None:
                return

            if data['type'] == 'lens':
                add_style = QAction('新建文件夹', self)
                add_style.triggered.connect(
                    lambda: self._add_child('style', data['id'], index))
                menu.addAction(add_style)
                menu.addSeparator()
                rename_action = QAction('重命名', self)
                rename_action.triggered.connect(lambda: self.tree.edit(index))
                menu.addAction(rename_action)
                delete_action = QAction('删除文件夹', self)
                delete_action.triggered.connect(
                    lambda: self._delete_tree_item('lens', data['id']))
                menu.addAction(delete_action)

            elif data['type'] == 'style':
                add_folder = QAction('新建文件夹', self)
                add_folder.triggered.connect(
                    lambda: self._add_child('folder', data['id'], index))
                menu.addAction(add_folder)
                menu.addSeparator()
                rename_action = QAction('重命名', self)
                rename_action.triggered.connect(lambda: self.tree.edit(index))
                menu.addAction(rename_action)
                delete_action = QAction('删除文件夹', self)
                delete_action.triggered.connect(
                    lambda: self._delete_tree_item('style', data['id']))
                menu.addAction(delete_action)

            elif data['type'] == 'folder':
                rename_action = QAction('重命名', self)
                rename_action.triggered.connect(lambda: self.tree.edit(index))
                menu.addAction(rename_action)
                delete_action = QAction('删除文件夹', self)
                delete_action.triggered.connect(
                    lambda: self._delete_tree_item('folder', data['id']))
                menu.addAction(delete_action)
        else:
            add_lens = QAction('新建文件夹', self)
            add_lens.triggered.connect(self._on_add_lens)
            menu.addAction(add_lens)

        if menu.actions():
            menu.exec(self.tree.viewport().mapToGlobal(pos))

    # ── add / rename / delete ────────────────────────────────

    def _on_add_lens(self):
        name, ok = QInputDialog.getText(self, '新建文件夹', '文件夹名称:')
        if ok and name.strip():
            create_lens(name.strip())
            self._refresh_tree()
            self.tree.expandAll()

    def _add_child(self, child_type: str, parent_id: int, parent_index):
        name, ok = QInputDialog.getText(self, '新建文件夹', '文件夹名称:')
        if ok and name.strip():
            if child_type == 'style':
                new_item = create_style(parent_id, name.strip())
                self._refresh_tree(expand_type='lens', expand_id=parent_id)
                self._select_tree_item('style', new_item.id)
            else:
                new_item = create_folder(parent_id, name.strip())
                self._refresh_tree(expand_type='style', expand_id=parent_id)
                self._select_tree_item('folder', new_item.id)

    def _select_tree_item(self, item_type, item_id):
        """Select a tree item by type and id after rebuild."""
        idx = self._find_item_index(item_type, item_id)
        if idx.isValid():
            self.tree.setCurrentIndex(idx)

    def _delete_tree_item(self, item_type: str, item_id: int):
        reply = QMessageBox.question(
            self, '确认删除',
            '确定要删除此项及其所有内容吗? 此操作不可撤销。',
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply != QMessageBox.Yes:
            return

        if item_type == 'lens':
            delete_lens(item_id)
        elif item_type == 'style':
            delete_style(item_id)
        elif item_type == 'folder':
            delete_folder(item_id)

        self._refresh_tree()
        self._clear_photo_grid()
        self._clear_note_editor()

    # ── tree selection → photos + notes ─────────────────────

    def _on_tree_selection_changed(self, selected, deselected):
        data = self._get_selected_item_data()
        if data is None:
            self._clear_photo_grid()
            self._clear_note_editor()
            self.import_btn.setEnabled(False)
            return

        self._selected_target = (data['type'], data['id'])
        self.import_btn.setEnabled(True)
        self.center_title.setText(data['name'])
        self._load_photos(data['type'], data['id'])
        self._load_notes(data['type'], data['id'])

    # ── photo grid ───────────────────────────────────────────

    def _load_photos(self, target_type: str, target_id: int):
        self.photo_model.clear()
        photos = get_photos_by_target(target_type, target_id)
        for p in photos:
            item = QStandardItem(p.format or 'IMG')
            item.setData({'type': 'photo', 'id': p.id, 'path': p.original_path}, Qt.UserRole)
            if os.path.exists(p.preview_path):
                pixmap = QPixmap(p.preview_path)
                if not pixmap.isNull():
                    item.setIcon(QIcon(pixmap))
            self.photo_model.appendRow(item)

    def _clear_photo_grid(self):
        self.photo_model.clear()
        self._selected_target = None
        self._clear_exif_display()

    # ── photo import ─────────────────────────────────────────

    def _on_import_photos(self):
        if self._selected_target is None:
            return
        files, _ = QFileDialog.getOpenFileNames(
            self, '选择照片', '',
            'Images (*.jpg *.jpeg *.png *.webp *.heic *.gif *.bmp)')
        if files:
            reply = QMessageBox.question(
                self, '复制照片',
                f'已选择 {len(files)} 张照片。\n是否复制一份到程序文件夹？\n（否则仅引用原路径）',
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            copy = (reply == QMessageBox.Yes)
            self._import_files(files, copy)

    def _import_files(self, files, copy: bool):
        if self._selected_target is None:
            return
        target_type, target_id = self._selected_target
        folder_id = ensure_target_folder(target_type, target_id)

        if copy:
            resolution = self.settings.get('copy_resolution', 'original')
            copied = []
            for f in files:
                try:
                    new_path = copy_photo(f, self.photos_dir, resolution)
                    copied.append(new_path)
                except Exception:
                    copied.append(f)  # fallback to original on error
            files = copied

        import_photos(folder_id, files, self.thumbnails_dir)
        self._refresh_tree()
        self._load_photos(target_type, target_id)

    def _on_open_settings(self):
        dlg = SettingsDialog(self.settings, self)
        if dlg.exec() == SettingsDialog.Accepted:
            self.settings = dlg.get_settings()
            save_settings(self.data_dir, self.settings)

    def _on_photo_double_click(self, index):
        item = self.photo_model.itemFromIndex(index)
        data = item.data(Qt.UserRole) if item else None
        if data and data['type'] == 'photo':
            path = data.get('path', '')
            if os.path.exists(path):
                os.startfile(path)

    def _on_photo_selection_changed(self, selected, deselected):
        indexes = selected.indexes()
        if not indexes:
            self._clear_exif_display()
            return
        item = self.photo_model.itemFromIndex(indexes[0])
        data = item.data(Qt.UserRole) if item else None
        if data and data['type'] == 'photo':
            self._load_notes('photo', data['id'])
            self._show_exif(data['id'])

    def _show_exif(self, photo_id: int):
        session = get_session()
        photo = session.query(Photo).filter_by(id=photo_id).first()
        if photo and photo.exif_data:
            lines = []
            if 'width' in photo.exif_data or photo.width:
                lines.append(f"尺寸: {photo.width} × {photo.height}")
            if 'format' in photo.exif_data or photo.format:
                lines.append(f"格式: {photo.format}")
            for k, v in photo.exif_data.items():
                lines.append(f"{k}: {v}")
            self.exif_browser.setPlainText('\n'.join(lines))
        else:
            self.exif_browser.setPlainText(f"格式: {photo.format}\n尺寸: {photo.width} × {photo.height}" if photo else '')
        session.close()

    def _clear_exif_display(self):
        self.exif_browser.clear()

    def _on_photo_context_menu(self, pos):
        index = self.thumbnail_grid.indexAt(pos)
        if not index.isValid():
            return
        item = self.photo_model.itemFromIndex(index)
        data = item.data(Qt.UserRole) if item else None
        if not data or data['type'] != 'photo':
            return

        menu = QMenu()
        delete_action = QAction('删除照片', self)
        delete_action.triggered.connect(lambda: self._delete_photo_action(data['id']))
        menu.addAction(delete_action)
        menu.exec(self.thumbnail_grid.viewport().mapToGlobal(pos))

    def _delete_photo_action(self, photo_id: int):
        reply = QMessageBox.question(
            self, '确认删除', '确定要删除这张照片吗?',
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            delete_photo(photo_id)
            if self._selected_target:
                self._load_photos(*self._selected_target)

    # ── notes ────────────────────────────────────────────────

    def _load_notes(self, target_type: str, target_id: int):
        self.note_editor.blockSignals(True)
        self._current_note_target = (target_type, target_id)
        notes = get_notes(target_type, target_id)
        if notes:
            content = notes[0].content
            self._note_id = notes[0].id
        else:
            content = ''
            self._note_id = None
        self.note_editor.setPlainText(content)
        self.note_editor.setEnabled(True)
        self.note_editor.blockSignals(False)

    def _clear_note_editor(self):
        self.note_editor.blockSignals(True)
        self.note_editor.clear()
        self.note_editor.setEnabled(False)
        self.note_editor.setPlaceholderText('选择照片或文件夹以添加笔记...')
        self._current_note_target = None
        self._note_id = None
        self.note_editor.blockSignals(False)

    def _on_note_text_changed(self):
        if self._current_note_target is None:
            return
        content = self.note_editor.toPlainText()
        target_type, target_id = self._current_note_target
        if self._note_id is None:
            if content.strip():
                note = create_note(target_type, target_id, content)
                self._note_id = note.id
        else:
            update_note(self._note_id, content)

    def _on_search_notes(self, text: str):
        if not text.strip():
            return
        from app.services.note_service import search_notes
        results = search_notes(text)
        # Show first result's note in the editor
        if results:
            note = results[0]
            self._current_note_target = (note.target_type, note.target_id)
            self._note_id = note.id
            self.note_editor.blockSignals(True)
            self.note_editor.setPlainText(note.content)
            self.note_editor.setEnabled(True)
            self.note_editor.blockSignals(False)

    # ── drag-drop support for the tree ───────────────────────

    def _on_tree_rows_moved(self, parent, start, end, destination, row):
        """Persist sort_order after drag-drop reorder."""
        self._persist_sort_order()

    def _persist_sort_order(self):
        session = get_session()
        root = self.tree_model.invisibleRootItem()
        for i in range(root.rowCount()):
            lens_item = root.child(i)
            lens_data = lens_item.data(Qt.UserRole)
            if lens_data and lens_data['type'] == 'lens':
                session.query(Lens).filter_by(id=lens_data['id']).update({'sort_order': i})
                for j in range(lens_item.rowCount()):
                    style_item = lens_item.child(j)
                    style_data = style_item.data(Qt.UserRole)
                    if style_data and style_data['type'] == 'style':
                        session.query(Style).filter_by(id=style_data['id']).update({'sort_order': j})
                        for k in range(style_item.rowCount()):
                            folder_item = style_item.child(k)
                            folder_data = folder_item.data(Qt.UserRole)
                            if folder_data and folder_data['type'] == 'folder':
                                session.query(Folder).filter_by(id=folder_data['id']).update({'sort_order': k})
        session.commit()
        session.close()
