"""Light minimalist theme for the photography app."""

from PySide6.QtGui import QPalette, QColor


def apply_theme(app):
    app.setStyle('Fusion')

    palette = app.palette()
    palette.setColor(QPalette.ColorRole.WindowText, QColor('#333333'))
    palette.setColor(QPalette.ColorRole.Button, QColor('#F5F5F5'))
    palette.setColor(QPalette.ColorRole.Base, QColor('#FFFFFF'))
    palette.setColor(QPalette.ColorRole.Window, QColor('#FAFAFA'))
    palette.setColor(QPalette.ColorRole.Highlight, QColor('#E3F2FD'))
    palette.setColor(QPalette.ColorRole.HighlightedText, QColor('#1976D2'))
    app.setPalette(palette)

    app.setStyleSheet("""
        QMainWindow {
            background: #FAFAFA;
        }
        QTreeView {
            background: #FFFFFF;
            border: none;
            outline: none;
            font-size: 13px;
            padding: 4px;
        }
        QTreeView::item {
            padding: 5px 4px;
            border-radius: 4px;
        }
        QTreeView::item:selected {
            background: #E3F2FD;
            color: #1976D2;
        }
        QTreeView::item:hover:!selected {
            background: #F5F5F5;
        }
        QTreeView::branch {
            background: transparent;
        }
        QListView {
            background: #FAFAFA;
            border: none;
            outline: none;
        }
        QListView::item {
            border-radius: 6px;
            margin: 3px;
        }
        QListView::item:selected {
            background: #E3F2FD;
        }
        QSplitter::handle {
            background: #E0E0E0;
            width: 1px;
        }
        QTextEdit {
            background: #FFFFFF;
            border: 1px solid #E0E0E0;
            border-radius: 6px;
            padding: 8px;
            font-size: 13px;
            color: #333333;
        }
        QLineEdit {
            background: #FFFFFF;
            border: 1px solid #E0E0E0;
            border-radius: 6px;
            padding: 6px 10px;
            font-size: 13px;
            color: #333333;
        }
        QLineEdit:focus, QTextEdit:focus {
            border-color: #90CAF9;
        }
        QPushButton {
            background: #FFFFFF;
            border: 1px solid #E0E0E0;
            border-radius: 6px;
            padding: 6px 16px;
            font-size: 12px;
            color: #333333;
        }
        QPushButton:hover {
            background: #F5F5F5;
            border-color: #BDBDBD;
        }
        QPushButton:pressed {
            background: #E0E0E0;
        }
        QPushButton#primaryBtn {
            background: #1976D2;
            color: #FFFFFF;
            border: none;
        }
        QPushButton#primaryBtn:hover {
            background: #1565C0;
        }
        QMenu {
            background: #FFFFFF;
            border: 1px solid #E0E0E0;
            border-radius: 6px;
            padding: 4px;
        }
        QMenu::item {
            padding: 6px 24px;
            border-radius: 4px;
        }
        QMenu::item:selected {
            background: #E3F2FD;
            color: #1976D2;
        }
        QToolBar {
            background: #FAFAFA;
            border-bottom: 1px solid #E0E0E0;
            padding: 4px;
            spacing: 4px;
        }
        QLabel#title {
            font-size: 16px;
            font-weight: 500;
            color: #333333;
        }
        QLabel#subtitle {
            font-size: 12px;
            color: #9E9E9E;
        }
    """)
