from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox,
    QPushButton, QGroupBox,
)
from PySide6.QtCore import Qt


class SettingsDialog(QDialog):
    def __init__(self, settings: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle('设置')
        self.setFixedSize(360, 180)
        self._settings = dict(settings)

        layout = QVBoxLayout(self)
        layout.setSpacing(16)

        # Resolution group
        group = QGroupBox('导入图片复制尺寸')
        group_layout = QVBoxLayout(group)

        row = QHBoxLayout()
        row.addWidget(QLabel('复制分辨率:'))
        self.res_combo = QComboBox()
        self.res_combo.addItem('原尺寸（不压缩）', 'original')
        self.res_combo.addItem('1080P (1920×1080)', '1080p')
        self.res_combo.addItem('720P (1280×720)', '720p')
        self.res_combo.addItem('540P (960×540)', '540p')

        current = self._settings.get('copy_resolution', 'original')
        idx = self.res_combo.findData(current)
        if idx >= 0:
            self.res_combo.setCurrentIndex(idx)

        row.addWidget(self.res_combo)
        group_layout.addLayout(row)
        layout.addWidget(group)

        layout.addStretch()

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        cancel = QPushButton('取消')
        cancel.clicked.connect(self.reject)
        btn_row.addWidget(cancel)
        save = QPushButton('保存')
        save.setObjectName('primaryBtn')
        save.clicked.connect(self._save)
        btn_row.addWidget(save)
        layout.addLayout(btn_row)

    def _save(self):
        self._settings['copy_resolution'] = self.res_combo.currentData()
        self.accept()

    def get_settings(self) -> dict:
        return self._settings
