from PIL import Image


def get_exif_strings(path: str) -> dict[str, str]:
    """Extract human-readable EXIF tags."""
    result = {}
    try:
        img = Image.open(path)
        exif = img.getexif()
        if exif:
            for k, v in exif.items():
                result[str(k)] = str(v)
    except Exception:
        pass
    return result
