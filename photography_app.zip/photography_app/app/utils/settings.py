"""App settings stored as JSON in data/settings.json."""
import json
import os

DEFAULT_SETTINGS = {
    'copy_resolution': 'original',  # 'original', '1080p', '720p', '540p'
}

RESOLUTION_OPTIONS = {
    'original': (None, None, '原尺寸'),
    '1080p': (1920, 1080, '1080P'),
    '720p': (1280, 720, '720P'),
    '540p': (960, 540, '540P'),
}


def get_settings_path(data_dir: str) -> str:
    return os.path.join(data_dir, 'settings.json')


def load_settings(data_dir: str) -> dict:
    path = get_settings_path(data_dir)
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return dict(DEFAULT_SETTINGS)


def save_settings(data_dir: str, settings: dict):
    path = get_settings_path(data_dir)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(settings, f, ensure_ascii=False, indent=2)
