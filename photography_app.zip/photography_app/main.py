import sys
import os

# Ensure the project root is on sys.path
project_dir = os.path.dirname(os.path.abspath(__file__))
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

from PySide6.QtWidgets import QApplication
from app.ui.main_window import MainWindow
from app.ui.theme import apply_theme
from app.database.repository import init_db


def main():
    app = QApplication(sys.argv)
    app.setApplicationName('摄影管理')

    apply_theme(app)

    data_dir = os.path.join(project_dir, 'data')
    os.makedirs(data_dir, exist_ok=True)
    db_path = os.path.join(data_dir, 'app.db')
    init_db(db_path)

    window = MainWindow(data_dir)
    window.show()

    sys.exit(app.exec())


if __name__ == '__main__':
    main()
